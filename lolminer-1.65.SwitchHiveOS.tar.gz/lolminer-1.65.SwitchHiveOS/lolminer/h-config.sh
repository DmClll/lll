#!/usr/bin/env bash

	local MINER_VER=$CUSTOM_VER
	[[ -z $MINER_VER ]] && MINER_VER=$MINER_LATEST_VER
	echo $MINER_VER

	local MINER_VER=`miner_ver`

	MINER_CONFIG="$MINER_DIR/$MINER_NAME/lolminer.conf"
	GLOBAL_CONFIG="$MINER_DIR/$MINER_NAME/global_config.conf"
	ALGO_CONFIG="$MINER_DIR/$MINER_NAME/algo.conf"
	TOKEN_CONFIG="$MINER_DIR/$MINER_NAME/token.txt"
	mkfile_from_symlink $MINER_CONFIG


	conf=""
	#POOL

#        conf+="$CUSTOM_URL\n"
	conf+="$CUSTOM_TEMPLATE\n"
	echo -e "$CUSTOM_PASS" > $TOKEN_CONFIG

	# TLS and other options
	[[ $CUSTOM_TLS -eq 1 ]] && conf+="--tls 1\n"

        echo -e "$CUSTOM_USER_CONFIG" > $ALGO_CONFIG 

        conf+="--apiport $CUSTOM_API_PORT\n"

	conf+=`cat $GLOBAL_CONFIG`"\n"

	echo -e "$conf" > $MINER_CONFIG

